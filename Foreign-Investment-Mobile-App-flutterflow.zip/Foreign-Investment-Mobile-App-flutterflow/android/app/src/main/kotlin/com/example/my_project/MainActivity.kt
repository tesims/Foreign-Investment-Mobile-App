package com.mycompany.glotek

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
